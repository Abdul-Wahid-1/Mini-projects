/**
 * Refers to the key the user must find to clear the floor
 *
 * @author Abdul Wahid
 * @version 1
 */
public final class key extends items
{

    /**
     * Constructor for objects of class key
     */
    public key(int block, int level)
    {
        super("Key",block,level);
    }
    
    /**
     * Prints a statement to the screen telling user they cleared floor
     * 
     * @param  
     * @return    
     */
    public void getDetails(){
        if(getactive())System.out.println("You found the key and therefore have cleared the floor");
        else super.getDetails();
        
    }
}
