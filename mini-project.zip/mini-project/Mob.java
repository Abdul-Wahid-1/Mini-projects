import java.util.Random;
/**
 * Mob refers to the characters the user encounters and fights
 *
 * @author Abdul Wahid
 * @version 1
 */
public class Mob extends Character
{
    
    private boolean attack;//measure of hostility
    /**
     * Constructor for objects of class Mob
     */
    public Mob(int health, int level, int block, int denominator, int numerator)
    {
        super(health,level,block);
        if((1+new Random().nextInt(denominator)) < numerator)attack = true;
        else attack = false;
    }

    /**
     *  prints details of super class and then hostility 
     *
     * @param  
     * @return    
     */
    public void getDetails()
    {
        super.getDetails();
        System.out.printf("%-14s","Hostile: "+attack);
    }
    
    /**
     * returns whether the mob is hostile or not
     *
     * @param  
     * @return    attack
     */
    public boolean getattack(){
        return attack;
    }
}
