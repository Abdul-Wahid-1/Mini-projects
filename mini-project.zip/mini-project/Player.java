/**
 * Class player refers to the character the user plays with
 *
 * @author Abdul Wahid
 * @version 1
 */
public class Player extends Character
{
    private String name;
    
    /**
     * Constructor for objects of class Player
     */
    public Player(String name, int health, int level, int block){
        super(health,level,block);
        this.name = name;
    }
    
    /**
     *  Prints out the details of the player i.e name health and coordinates 
     *
     * @param  
     * @return    
     */
    public void getDetails(){
        System.out.print("Name: " + name + " ");
        super.getDetails();
        System.out.println("\n");
    }
    
    /**
     * Checks whether the player is alive and returns true or false depending on it
     *
     * @param  
     * @return    true/false
     */
    public boolean alive(){
        if(this.getHealth()>0)return true;
        else return false;
        
    }
    
    /**
     * returns the details of the player as a string
     *
     * @param  
     * @return    "Name: " + name +  "\nHealth: " + super.getHealth()+"\n"+
        super.getcoordinates()
     */
    public String returnDetails(){
        return "Name: " + name +  "\nHealth: " + super.getHealth()+"\n"+
        super.getcoordinates();
    }
    
    /**
     * prints out the players health
     *
     * @param  
     * @return    
     */
    public void printHealth(){
        System.out.println("Name: "+name+ " Health: "+ super.getHealth());
    }
}
