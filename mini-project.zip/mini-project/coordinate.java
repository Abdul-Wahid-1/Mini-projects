
/**
 * Write a description of interface coordinate here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface coordinate
{
    /**
     * getblock 
     *
     * @param  
     * @return   block
     */
    public int getblock();
    
    /**
     * getlevel 
     *
     * @param  
     * @return   level
     */
    public int getlevel();
    
    /**
     * changeblock 
     *
     * @param  newblock
     * @return   
     */
    public void changeblock(int newblock);
    
    /**
     * changelevel 
     *
     * @param  newlevel
     * @return   
     */
    public void changelevel(int newlevel);
}
