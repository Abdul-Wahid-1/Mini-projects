
/**
 * Refers to the items that deal damage (either to the user or mobs)
 *
 * @author Abdul Wahid
 * @version 1
 */
public abstract class Attackitem extends items
{
    private int damagedealt;

    /**
     * Constructor for objects of class Attackitem
     */
    public Attackitem(String name, int damagedealt, int Xposition, int Yposition)
    {
        super(name,Xposition,Yposition);
        this.damagedealt = damagedealt;
    }

    /**
     * returns the damage dealt
     *
     * @param  
     * @return    damagedealt
     */
    public int getdamagedealt()
    {
        return damagedealt;
    }
    
    /**
     * Changes the damage dealt to a new
     *
     * @param  newdamage
     * @return    
     */
    public void setdamagedealt(int newdamage){
        damagedealt = newdamage;
    }
    
    /**
     * Increments/Decrements the damage dealt
     *
     * @param  newdamage
     * @return    
     */
    public void changedamagedealt(int newdamage){
        damagedealt += newdamage;
    }
}
