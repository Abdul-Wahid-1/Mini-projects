
/**
 * items refers to the items that can be picked up or act as traps
 *
 * @author Abdul Wahid
 * @version 1
 */
public abstract class items implements details, coordinate
{
    private boolean active;
    private int level;//y position
    private int block;//x position
    private String name;
    
    /**
     * Constructor for objects of class items
     */
    public items(String name, int block, int level)
    {
        this.name = name;
        this.block = block;
        this.level = level;
        active = false;
    }

    /**
     * active -this returns the active of the item
     *
     * @param  
     * @return    active
     */
    public boolean getactive()
    {
        return active;
    }
    
    /**
     * getName this returns the items name
     *
     * @param  
     * @return name
     */
    public String getName(){
        return name;
    }
    
    /**
     * Makes the item active i.e opens chests  
     *
     * @param  
     * @return    active
     */
    public void open(){
        active = true;
    }
    
    /**
     * this returns the position of the x coordinate (block)
     *
     * @param  
     * @return    block
     */
    public int getblock(){
        return block;
    }
    
    /**
     * returns the position of the y coordinate (level)
     *
     * @param  
     * @return    level
     */
    public int getlevel(){
        return level;
    }
    
    /**
     * Changes the value of the block to a new
     *
     * @param  newblock
     * @return    
     */
    public void changeblock(int newblock){
        block = newblock;
    }
    
    /**
     * Changes the value of the level to a new
     *
     * @param  newlevel
     * @return    
     */
    public void changelevel(int newlevel){
        level = newlevel;
    }
    
    /**
     * Prints out the details of the item i.e. the coordinates and whether it is open
     * or not
     *
     * @param  
     * @return    
     */
    public void getDetails(){
        System.out.println("Chest, Level: " + level + " Block: " + block+" Open: "+active);
    }
}
