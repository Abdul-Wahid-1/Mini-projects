
/**
 * Used to define the traits that all characters have
 *
 * @author Abdul Wahid
 * @version 1
 */
public class Character implements details,coordinate
{
    private int health;
    private int level;//y position
    private int block;//x position
    
    /**
     * Constructor for objects of class Character
     */
    public Character(int health,int level, int block)
    {
        this.health = health;
        this.level = level;
        this.block = block;
    }

    /**
     * returns the variable health
     *
     * @param  
     * @return    health
     */
    public int getHealth(){
        return health;
    }
    
    /**
     * prints out the details of the character i.e. health and coordinates 
     * using system.out.printf to make it look cleaner
     * @param  
     * @return    
     */
    public void getDetails(){
        final int spacing = 3;
        int x = -("Health: ".length()+3);
        int y = -(String.valueOf(level).length()+spacing+"Level: ".length());
        int z = -(String.valueOf(block).length()+spacing +"Block: ".length());
        System.out.printf("%"+x+"s %"+y+"s %"+z+"s " ,"Health: "+health,"Level: "+level ,"Block: "+ block);
    }
    
    /**
     * Increments/decrements health by another value
     *
     * @param  
     * @return    
     */
    public void changeHealth(int changeValue){
        health += changeValue;
    }
    
    /**
     * returns the x coordinate of the character
     *
     * @param  
     * @return    block
     */
    public int getblock(){
        return block;
    }
    
    /**
     * returns the y coordinate of the character
     *
     * @param  
     * @return    level
     */
    public int getlevel(){
        return level;
    }
    
    /**
     * Increments/decrements the level by a certain value
     *
     * @param  newlevel
     * @return    
     */
    public void changelevel(int newlevel){
        level += newlevel;
    }
    
    /**
     * Increments/decrements the block by a certain value
     *
     * @param  newblock
     * @return    
     */
    public void changeblock(int newblock){
        block += newblock;
    }
    
    /**
     * resets the players stats by making everything back to its original status
     *
     * @param  
     * @return    
     */
    public void resetPlayer(int newHealth){
        health = newHealth;
        block = 1;
        level = 1;
    }
    
    /**
     * returns the y coordinate and x coordinate of the character
     *
     * @param  
     * @return    ("Level: " + level + " Block: "+ block)
     */
    public String getcoordinates(){
        return ("Level: " + level + " Block: "+ block);
    }
    
    /**
     * prints out the health of the mob statement depends on mob type
     *
     * @param  
     * @return    
     */
    public void printHealth(){
        if(this instanceof AdvancedMob){
            if(health>0)System.out.println("Advance Mob Health: "+health);
            else System.out.println("Advance Mob Health: 0\nYou slayed the Advanced Mob");
        }
        else if(this instanceof MinorMob){
            if(health>0)System.out.println("Minor Mob Health: "+ health);
            else System.out.println("Minor Mob Health: 0\nYou slayed the Minor Mob");
        }
    }
    
    /**
     * makes the character inaccessible i.e. making sure there is no possibilty of 
     * coming across them
     *
     * @param  
     * @return    
     */
    public void inexistent(){
        block=0;
        level =0;
    }
}
