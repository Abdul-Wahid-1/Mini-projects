import java.util.Random;
/**
 * Chest spawns chests containing items that the user can interact with 
 *
 * @author Abdul Wahid
 * @version 1
 */
public class Chest implements details
{
    private items [] chests;

    /**
     * Constructor for objects of class Chest
     */
    public Chest(int random,int absolute, int block,int level)
    {
        Random num = new Random();
        chests = new items[num.nextInt(random)+absolute];
        int f = num.nextInt(chests.length-1);            
        int x = num.nextInt(block)+1;
        int y = num.nextInt(block)+2;
        for(int i = 0;i<chests.length;i++){
            int k = num.nextInt(chests.length-1);
            while(i>0&&(chests[i-1].getblock()==x|chests[i-1].getlevel()==y)){
                x  = num.nextInt(block)+1;//+1 has to spawn 1 +
                y = num.nextInt(level)+2;//+2 cannot spawn on ground floor
            }
            if(i==f) chests[i] = new key(x,y);
            else{
                if(k>((chests.length-1)/2))chests[i] = new Bomb(15,2,x,y);
                else chests[i] = new Weapon(15,false,x,y);
            }            
        }
    }
    
    /**
     * prints out the details of the chest also checks whether they are already 
     * open or not and then prints out all closed chests
     *
     * @param  
     * @return    
     */
    public void getDetails(){
        int count =0;
        for(int i =0;i<chests.length;i++){
            if(chests[i].getactive()){
                chests[i].changeblock(0);
                chests[i].changelevel(0);
                count++;
            }
        }
        System.out.println("There are " + (chests.length-count) + " closed chests.");
        for(int i =0;i<chests.length;i++){
            if(!chests[i].getactive())chests[i].getDetails();
        }
        System.out.println("\n");
    }
        
    /**
     * First checks whether user and chest on same coordinate if so allows user
     * interaction and does something according to the item i.e. progress floor
     * reduce health or equip weapon
     * 
     * @param  Player player
     * @return    
     */
    public void open(Player player){
        Random num = new Random();
        int k = num.nextInt(chests.length-1);
        for(int i =0;i<chests.length;i++){
            if(player.getlevel() == chests[i].getlevel() && player.getblock() == chests[i].getblock() && !(chests[i].getactive())){
                String input = testtower.inputstring("\nThere is a chest would you like to open it (y/n) ? ");
                if(input.equals("y")){
                    chests[i].open();
                    if(chests[i] instanceof key){
                        chests[i].getDetails();
                        i = chests.length;
                    }else if(chests[i] instanceof Bomb){
                        int j = ((Attackitem)chests[i]).getdamagedealt()+num.nextInt(10);
                        player.changeHealth(-j);
                        chests[i].getDetails();
                        System.out.println(j+" damage");                            
                    }else{
                        String a = testtower.inputstring("You found a weapon would you like to epuip it (y/n)").toLowerCase();
                        if(a.equals("y"))((Weapon)chests[i]).equip(true);
                    }
                }
            }
        }
    }
    
    /**
     * Changes the damagedealt by each bomb
     *
     * @param  int change
     * @return    
     */
    public void changebombdamage(int change){
        for(int i =0;i<chests.length;i++){
            if(chests[i] instanceof Bomb)((Attackitem)chests[i]).changedamagedealt(change);
        }
    }

    /**
     * Changes the damagedealt by each weapon
     *
     * @param  int change
     * @return    
     */
    public void changeweapondamage(int change){
        for(int i =0;i<chests.length;i++){
            if(chests[i] instanceof Weapon)((Attackitem)chests[i]).changedamagedealt(change);
        }
    }

    /**
     * gets the damage of the weapons
     *
     * @param   
     * @return    damage
     */
    public int getweapondamage(){
        int damage=0;
        for(int i =0;i<chests.length;i++){
            if(chests[i] instanceof Weapon){
                damage = ((Attackitem)chests[i]).getdamagedealt();
                i=chests.length;
            }
        }      
        return damage;
    }

    /**
     * checks whether the user has a weapon equipped or not
     *
     * @param  
     * @return    check (true/false)
     */
    public boolean isequipped(){
        boolean check = false;
        for(int i =0;i<chests.length;i++){
            if(chests[i] instanceof Weapon){
                if(((Weapon)chests[i]).isequip())check=true;
            }
        }
        return check;
    }
    
    /**
     * Checks whether user has found a key or not
     *
     * @param  
     * @return    check (true or false)
     */
     public boolean checkKey(){
        boolean check = false;
        for(int i =0;i<chests.length;i++){
            if(chests[i].getName().equals("Key")&&chests[i].getactive()){
                check = true;
                i = chests.length;
            }
        }
        return check;
    }
    
    /**
     * checks if there is ammo left in any weapon
     *
     * @param  
     * @return  true/false
     */
    public boolean ammo(){
        int count =0;
        boolean check = false;
        for(int i =0;i<chests.length;i++){
            if(chests[i] instanceof Weapon){
               if(((Weapon)chests[i]).ammo())count++;
            }
        }
        if(count>0)return true;
        else return false;
    }
    
    /**
     * decrements bullet 
     *
     * @param  
     * @return    
     */
    public void shot(){
        for(int i =0;i<chests.length;i++){
            if(chests[i] instanceof Weapon && chests[i].getactive()){
                ((Weapon)chests[i]).shot();
                i= chests.length;
            }
        }    
    }
}
