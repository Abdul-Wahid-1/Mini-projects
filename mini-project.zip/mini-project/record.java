/**
 * Is a record used to hold and change values of Mob class and sub classes many values
 * thus required to create a record
 * 
 * @author Abdul Wahid
 * @version 1
 */
class record
{
    private int attackDenominator;
    private int attackNumerator;
    
    private int gunDenominator;
    private int gunNumerator;
    
    private int swordNumerator;
    private int swordDenominator;
    
    /**
     * Constructor for objects of class Chest
    */
    public record(){
        attackDenominator = 10;
        attackNumerator = 2;
        gunNumerator = 2;
        gunDenominator = 10;
        swordNumerator = 2;
        swordDenominator = 10;
    }
    
    /**
     * returns the attackDenominator
     *
     * @param  
     * @return    attackDenominator
     */
    public int getattackDenominator(){
        return attackDenominator;
    }
    
    /**
     * returns the attackNumerator
     *
     * @param  
     * @return    attackNumerator
     */
    public int getattackNumerator(){
        return attackNumerator;
    }
    
    /**
     * returns the gunDenominator
     *
     * @param  
     * @return    gunDenominator
     */
    public int getgunDenominator(){
        return gunDenominator;
    }
    
    /**
     * returns the gunNumerator
     *
     * @param  
     * @return    gunNumerator
     */
    public int getgunNumerator(){
        return gunNumerator;
    }
    
    /**
     * returns the swordNumerator
     *
     * @param  
     * @return   swordNumerator
     */
    public int getswordNumerator(){
        return swordNumerator;
    }
    
    /**
     * returns the swordDenominator
     *
     * @param  
     * @return swordDenominator   
     */
    public int getswordDenominator(){
        return swordDenominator;
    }
    
    /**
     * Increments/decrements  the denominators by a certain value
     *
     * @param  record r, int denominator1, int denominator2, int denominator3
     * @return    
     */
    public static void changedenominator(record r, int denominator1, int denominator2, int denominator3){
        r.attackDenominator += denominator1;
        r.gunDenominator += denominator2;
        r.swordDenominator += denominator3;
    }
    
    /**
     * increments/decrements the numerators by a certain value
     *
     * @param  
     * @return    record r, int numerator1, int numerator2, int numerator3
     */
    public static void changenumerator(record r, int numerator1, int numerator2, int numerator3){
        r.attackNumerator += numerator1;
        r.gunNumerator += numerator2;
        r.swordDenominator += numerator3;
    }
}

