import java.util.Random;
/**
 * MinorMob is a weaker mob (opponent the user can fight) that can have a sword
 *
 * @author Abdul Wahid
 * @version 1
 */
public class MinorMob extends Mob
{
    private boolean sword;
    
    /**
     * Constructor for objects of class MinorMob
     */
    public MinorMob(int health, int level,int block,record r)
    {
        super(health,level,block,r.getattackDenominator(),r.getattackNumerator());
        if(new Random().nextInt(r.getswordDenominator())>r.getswordNumerator())sword = true;
        else sword = false;
    }
    
    /**
     *  prints out whether the the minor mob has a sword or not 
     *
     * @param  
     * @return    
     */
    public void getDetails(){
        super.getDetails();
        System.out.print(" Sword: "+sword);
    }
    
    /**
     * returns the value of variable sword
     *
     * @param  
     * @return    sword
     */
    public boolean getSword(){
        return sword;
    }
}
