import java.util.Scanner;
import java.util.Random;
import javax.swing.*;
/**
 * Contains main and brings together all other classes by creating instances
 * and contains only static methods 
 * 
 * @author Abdul Wahid
 * @version 1
 */
public class testtower
{
    /**
     * Where most instances and variables are created and incremented/decremented
     * according to floor number making the game progressively harder
     *
     * @param  String[] args
     * @return    
     */
    public static void main(String[] args){
      Player  player = player_initiation();
      record Record = new record();
      
      int chest_random = 1;
      int chest_absolute = 2;
      int mob_random = 1;
      int mob_absolute = 2;
      int floor_count=1;
      int chance = 6;
      int block = 3;
      int level = 2;
      
      while(player.alive()){
            player.resetPlayer(50);
            floorinfo(floor_count,level,block);
            
            //Declarations
            Chest chest = new Chest(chest_random,chest_absolute,level,block);
            Random num = new Random();
            Mob[] mob= new Mob[mob_absolute+num.nextInt(mob_random)];
            int mobs [] = generateMob(mob, level,block,chance,Record);
            
            findingkey(player,chest,mob,mobs,level,block);
            
            //incrementations
            level++;
            block++;
            chance+=2;
            chest_absolute++;
            chest_random +=3;
            mob_absolute +=2;
            mob_random *= 2;
            floor_count++;
            chest.changebombdamage(5);
            chest.changeweapondamage(3);
        }
        printj("You're dead x_x\nYou survived "+floor_count+" floors");
    }
    
    /**
     * Used to check whether the user has found the key or not
     * keeps repeating until user has found it or is dead
     *
     * @param  Player player, Chest chest,Mob[]mob,int []mobs,int level,int block
     * @return    
     */
    public static void findingkey(Player player, Chest chest,Mob[]mob,int []mobs,int level,int block){
        while(!chest.checkKey()&&player.alive()){
            chest.getDetails();
            print_mob(mob, mobs);
            player.getDetails();
            makemove(player,chest,mob,level+3,block+1);    
            chest.open(player);
            println("________________________________________________________________\n");
        }
    }
    
    /**
     * Used to print the floor number and number of levels and blocks to the screen
     *
     * @param  int floor_count, int level, int block
     * @return    
     */
    public static void floorinfo(int floor_count, int level, int block){
        println("\n\n________________________________________________________________");
        println("____________________________Floor "+floor_count+"____________________________");
        println("________________________________________________________________\n");
        println("Number of levels: "+(level+3)+ "\nNumber of blocks: "+(block+1)+"\n\n");
    }
    
    /**
     * Used to tell user the instructions and then allows user to input name 
     *
     * @param  
     * @return    
     */
    public static Player player_initiation(){
        instructions();
        String name = inputj("Please enter your username: ");
        while(name.isEmpty())name = inputj("\nInvalid input, please re-enter a valid username: ");
        Player player = new Player(name,50,1,1);
        player.getDetails();
        println("");
        return player;
    }
    
    /**
     * allows user to enter an input and using other methods moves or prints message
     *  accordingly
     *  
     * @param  Player player,Chest chest, Mob[]mob,int level, int block
     * @return    
     */
    public static void makemove(Player player,Chest chest, Mob[]mob,int level, int block){
        String move = inputstring("What would you like to do(enter C for controls)?").toUpperCase();
        while(!validinput(move)){
            if(move.equals("EXIT"))System.exit(0);
            println("\nInvalid input -- please re-enter");
            move = inputstring("What would you like to do?").toUpperCase();
        }
        move(player,chest,mob,move,level,block);
        println("\n");    
    }
    
    /**
     * prints out the instructions to the screen along with controls
     *
     * @param  
     * @return    
     */
    public static void instructions(){
        println("----Tower Climb----");
        printj("Welcome to tower climb,\nThe game where you climb the tower \nIn attempt to get the highest score");
        printj("But watch out....\nIt won't be that easy");
        printj("Mobs will be guarding floors\nMobs who are hostile will attack you if you encounter them otherwise they'll act as an obstacle\nTry evade/fight them off in attempt to look for the key (hidden in a chest)\nupon finding the key you will have cleared the floor");
        controls();
        printj("Thats all, Good Luck :)");
    }
    
    /** 
     * Used to check whether player has encountered a mob by checking whether their
     *  positions are the same or not checks hostility and prints message accordingly
     *
     * @param  Player player, Mob[] mob,char input
     * @return    check
     */
    public static boolean encounter(Player player, Mob[] mob,char input){
        boolean check = false;
        for(int i = 0;i<mob.length;i++){
            if(player.getlevel()==mob[i].getlevel()&&mob[i] instanceof AdvancedMob && mob[i].getattack())advancemobattack(player,mob,i);
            else if(player.getlevel() == mob[i].getlevel() && player.getblock()==mob[i].getblock()){
                if(mob[i].getattack()){
                    println("Oh no, you've encountered a hostile mob");
                    check = true;
                    if(mob[i] instanceof MinorMob)minormobattack(player,mob,i); 
                }else if(input!='J'&&((mob[i].getblock()-1)==player.getblock()|(mob[i].getblock()+1)==player.getblock())){
                    printj("You must jump over the mob at "+player.getcoordinates()+"\nHint: press JRD or JLD");
                    check = true;
                }
            }     
        }
        return check;
    }

    /**
     * Used to check whether advanced mob has a gun then attacks accordingly
     *
     * @param  Player p, Mob[] m,char a,int i
     * @return    
     */
    public static void advancemobattack(Player player, Mob[] mob,int i){
        if(((AdvancedMob)mob[i]).getGun())attack(player,mob,i,"The Advanced mob attacked you with his gun",25,5);
        else attack(player,mob,i,"The Advanced mob attacked you with his fists",10,5);
    }
    
    /**
     * Used when the player is jousting with any mob allows player to attack back or heal
     *  the damage is dealt randomly with values passed through parameters
     *  
     * @param  Player player, Mob[] mob,int i,String str,int variable, int constant
     * @return    
     */
    public static void attack(Player player, Mob[] mob,int i,String str,int variable, int constant){
        Random num = new Random();
        while(mob[i].getHealth()>0&&player.getHealth()>0){
            println("\n"+str+"\n");
            player.changeHealth(-(num.nextInt(variable)+constant));
            player.getDetails();
            String input = inputstring("\nWould you like to attack it or reheal (A/H)? ").toUpperCase();
            if(input.equals("A")){
                mob[i].changeHealth(-(num.nextInt(30)+20));
                println("\nYou attacked the mob");
                mob[i].printHealth();
            }else if(input.equals("H")){
                int k = num.nextInt(30)+20;
                player.changeHealth(k);
                println("\nYou healed gaining "+k+" health" );
            }else if(input.equals("Q"))printj(player.returnDetails());
            else println("\nThat was an invalid option -- please re-enter");  
        }
    }
    
    /**
     * Used to check whether mob hasa a sword or not and then attacks
     *
     * @param  Player player, Mob[] mob,char input,int i
     * @return    
     */
    public static void minormobattack(Player player, Mob[] mob,int i){
        if(((MinorMob)mob[i]).getSword())attack(player,mob,i,"The minor mob attacked you with his sword",20,10);
        else attack(player,mob,i,"The minor mob attacked you with his fists",10,5);
    }
    
    /**
     * Used so that the player can enter input to move or shoot or view stats/controls
     *
     * @param  Player player,Chest chest,Mob[] mob,String input,int level, int block
     * @return    
     */
    public static void move(Player player,Chest chest,Mob[] mob,String input,int level, int block){
        if(input.equals("C"))controls();
        else if(input.equals("Q"))printj(player.returnDetails());
        else if(input.equals("SE")){
            if(chest.isequipped()&&chest.ammo()){shootEast(player,mob,chest);chest.shot();}
            else if(!chest.ammo()) printj("Whoops looks like you have no ammo");
            else printj("Whoops it looks like you have no weapons");
        }else if(input.equals("SW")){
            if(chest.isequipped()&&chest.ammo()){shootWest(player,mob,chest);chest.shot();}
            else if(!chest.ammo()) printj("Whoops looks like you have no ammo");
            else printj("Whoops it looks like you have no weapons");
        }else{
            for(int i =0; i< input.length();i++){
                if(encounter(player,mob,input.charAt(i)))i=input.length();
                else if(input.charAt(i)=='R'){
                    if(player.getblock()==block)println("Cannot go anymore right");
                    else player.changeblock(1);
                }else if(input.charAt(i)=='L'){
                    if(player.getblock() == 1)println("Cannot go anymore left");
                    else player.changeblock(-1);
                }else if(input.charAt(i)=='J'){
                    if(player.getlevel()==level)println("Cannot go any higher");
                    else player.changelevel(1);
                }else{
                    if(input.charAt(i)=='D'&&player.getlevel()!=1)player.changelevel(-1);
                    else println("You cannot go any lower");
                }
            }
        }
    }

    /**
     * Used so that player can shoot east when mobs are on same level and gun is    
     *  equipped prints message to screen after shooting
     *
     * @param  Player player,Mob [] mob, Chest chest
     * @return    
     */
    public static void shootEast(Player player,Mob [] mob, Chest chest){
        int count =0;
        for(int i=0;i<mob.length;i++){
            if(player.getlevel()==mob[i].getlevel()){
                if(player.getblock()<mob[i].getblock()){
                    mob[i].changeHealth(-(new Random().nextInt(9)+chest.getweapondamage()));
                    count++;
                }
            }
        }
        if(count==0)printj("There were no mobs in that direction");
        else println("You hit "+ count +" mobs");
    }
    
    /**
     * Used so that player can shoot west when mobs are on same level and gun is    
     *  equipped prints message to screen after shooting
     *
     * @param  Player player,Mob [] mob, Chest chest
     * @return    
     */
    public static void shootWest(Player player,Mob [] mob, Chest chest){
        int count =0;
        for(int i=0;i<mob.length;i++){
            if(player.getlevel()==mob[i].getlevel()){
                if(player.getblock()>mob[i].getblock()){
                    mob[i].changeHealth(-(new Random().nextInt(9)+chest.getweapondamage()));
                    count++;
                }
            }
        }
        if(count==0)println("There were no mobs in that direction");
        else println("You hit "+ count +" mobs");
    }
    
    /**
     * Used to check whether the user has entered a valid input
     *
     * @param  String input
     * @return    valid
     */
    public static boolean validinput(String input){
        boolean valid = true;
        if(input.isEmpty()){
            valid = false;
        }
        for(int i =0; i<input.length();i++){
            if(!(input.charAt(i)=='R'|input.charAt(i)=='L'|input.charAt(i)=='J'|input.charAt(i)=='D'|(input.charAt(0)=='C'&&input.length()==1)|(input.charAt(0)=='Q'&&input.length()==1)|input.equals("SE")|input.equals("SW"))){
                valid = false;
                i = input.length();
            }
        }
        return valid;
    }
    
    /**
     * Used to print the controls the user can use to the screen
     *
     * @param  
     * @return    
     */
    public static void controls(){
        printj("Controls\nmove right = R\n"
                           + "move left = L\n"
                           + "jump = J (jumps up a level)\n"
                           + "climb down = D (climbs down a level)\n"
                           + "At any point enter Q for your stats\n"
                           +"SE to shoot east and SW to shoot west (shoots all oponents in direction)\n"
                           +"Additional info: You can do multiple movements in turn e.g. RRJ\n"
                           + "This moves the player right twice and jumps/climbs");
    }
    
    /**
     *  Generates a minormob or advanced mob with a random posibility this is value 
     *  is passed as parameters so it can be changed i.e. more advanced mobs spawn
     *  progressively also returns b which holds number of minor and advanced mobs
     *  
     * @param  Mob [] mob, int level, int block, int chance ,record records
     * @return    mobcount
     */
    public static int[] generateMob( Mob [] mob, int level, int block, int chance ,record records){
        int m_mobcount =0;
        int a_mobcount = 0;
        for(int i = 0;i<mob.length;i++){
            Random num = new Random();
            int j = num.nextInt(chance);
            int b = num.nextInt(block)+1;
            int l = num.nextInt(level)+2;
            if(j<9){
                m_mobcount++;
                mob[i] = new MinorMob(100,2+l,1+b,records);
            }else{
                a_mobcount++;
                mob[i] = new AdvancedMob(200,2+l,1+b,records);
            }
        }
        int mobcount[] = {m_mobcount , a_mobcount};
        return mobcount;
    }
    
    /**
     * takes a parameter mob and checks whether these are alive or not then prints out
     * how many mobs there are and each mob (depending on whether they are alive)
     * 
     * @param  Mob [] mob, int [] mobcount
     * @return    
     */
    public static void print_mob(Mob [] mob, int [] mobcount){
        int m_mobcount = mobcount[0];
        int a_mobcount = mobcount[1];
        for(int i =0;i<mob.length;i++){
            if(!(mob[i].getHealth()>0)&&mob[i] instanceof MinorMob){
                m_mobcount--;
                mob[i].inexistent();
            }else if(!(mob[i].getHealth()>0)&&mob[i] instanceof AdvancedMob){
                a_mobcount--;
                mob[i].inexistent();
            }
        }
        println("There are " + m_mobcount + " Mobs and "+a_mobcount + " Advanced Mobs" );
        for(int i = 0;i<mob.length;i++){
            if(mob[i].getHealth()>0){
                if(mob[i] instanceof AdvancedMob) mob[i].getDetails();
                else mob[i].getDetails();
                println("");
            }
        }
        println("\n");
    }
    
    /**
     * Shorthand method for input using joptionpane
     *
     * @param  String input
     * @return    JOptionPane.showInputDialog(input)/(the message)
     */
    public static String inputj(String input){
        return JOptionPane.showInputDialog(input);
    }
    
    /**
     * Shortand method for printing message to screen using joptionpane
     *
     * @param  String message
     * @return    
     */
    public static void printj(String message){
        JOptionPane.showMessageDialog(null, message);
    }
    
    /**
     * Passes a paramter as a question i.e. telling the user to input something
     * and then allows user to input through scanner and takes this value and returns
     * it
     *
     * @param  String question
     * @return    scanner.nextLine()
     */
    public static String inputstring(String question){
        Scanner scanner = new Scanner(System.in);
        System.out.print(question);
        return scanner.nextLine();
    }
    
    /**
     * Shorthand method for System.out.println
     *
     * @param  String message
     * @return    
     */
    public static void println(String message){
        System.out.println(message);
    }
}