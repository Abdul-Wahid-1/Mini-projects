/**
 * Contains method getDetails which is used by a few classes
 *
 * @author Abdul Wahid
 * @version 1
 */
public interface details
{
    /**
     * getDetails - method prints details pertaining to the object
     *
     * @param  
     * @return   
     */
    void getDetails();
}
