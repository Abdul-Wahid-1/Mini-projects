/**
 * Class for weapons that the user can equip
 *
 * @author Abdul Wahid
 * @version 1
 */
public class Weapon extends Attackitem
{
    private boolean equipped;
    private int bullets;

    /**
     * Constructor for objects of class Weapon
     */
    public Weapon(int damage, boolean equipped, int Xposition, int Yposition)
    {
        super("Weapon",damage,Xposition,Yposition);
        bullets = 5;
        this.equipped = equipped;
    }

    /**
     * equip used to equip or unequip weapon
     *
     * @param equipped  
     * @return 
     */
    public void equip(boolean equipped)
    {
        this.equipped = equipped;
    }
    
    /**
     * Returns the value of variable equipped
     *
     * @param  
     * @return    equipped
     */
    public boolean isequip(){
        return equipped;
    }
    
    /**
     * Decrements bullets by 1
     *
     * @param  
     * @return    
     */    
    public void shot(){
        if (bullets>=-1)bullets--;
    }
    
    /**
     * Checks if there is ammo left
     *
     * @param  
     * @return    true/false
     */
    public boolean ammo(){
        if(bullets>0)return true;
        else return false;
    }
}
