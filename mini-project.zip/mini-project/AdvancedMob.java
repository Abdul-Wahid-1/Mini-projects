import java.util.Random;
/**
 * Advanced Mob is a stronger Mob (Opponent the user can fight) that can have a gun 
 *
 * @author Abdul Wahid
 * @version 1
 */
public class AdvancedMob extends Mob
{
    private boolean gun;
    
    /**
     * Constructor for objects of class AdvancedMob
     */
    public AdvancedMob(int health,int level, int block, record r)
    {
        super(health,level,block,r.getattackDenominator(),r.getattackNumerator());
        
        if(new Random().nextInt(r.getgunDenominator()) > r.getgunNumerator())gun = true;
        else gun = false;
    }
    
    /**
     * returns the value of variable gun
     *
     * @param  
     * @return    gun
     */
    public boolean getGun(){
        return gun;
    }
    
    /**
     * prints out whether the advanced mob has a gun or not
     *
     * @param  
     * @return    
     */
    public void getDetails(){
        super.getDetails();
        System.out.printf("%-17s"," gun:   " + gun);
    }
}
