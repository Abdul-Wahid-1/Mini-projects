    
/**
 * Bomb refers to the Bomb that the user can encounter
 *
 * @author Abdul Wahid
 * @version 1
 */
public class Bomb extends Attackitem
{
    private int range;
    /**
     * Constructor for objects of class Bomb
     */
    public Bomb(int damage, int range, int block, int level)
    {
        super("Bomb",damage,block,level);
        this.range = range;
    }
    
    /**
     * getDetails - checks status of object and gets details
     *
     * @param
     * @return   
     */
    public void getDetails(){
        if(getactive())System.out.print("You found a bomb it has dealed you ");
        else super.getDetails();
    }
}
